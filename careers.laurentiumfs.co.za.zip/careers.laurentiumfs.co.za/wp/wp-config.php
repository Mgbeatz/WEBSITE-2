<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'laurenti_wp306' );

/** MySQL database username */
define( 'DB_USER', 'laurenti_wp306' );

/** MySQL database password */
define( 'DB_PASSWORD', 'N!r3S--p0-a3.ix1' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '1udy7dqlm5psnxdhel4uugdjbava2s3k4eqcj0ayjk68agrgtaauqftt4duzxaom' );
define( 'SECURE_AUTH_KEY',  'pizjzrofi78x1c4hdw1xhoi8r0ksgf7suqgsxj5lrznlrgltvhqkksmy7ztws31v' );
define( 'LOGGED_IN_KEY',    'uaraiyphqq7zjzl3229qqak36du4mfjrrs7ovfmobui8kss9e97rfsh8lhxsjxf7' );
define( 'NONCE_KEY',        '9tmfzeurmiy1x0woageb23p5x4lvysa7274smyzqqniydm2vbooh48r9ogrnpcl8' );
define( 'AUTH_SALT',        'u3juotf5xxmsh38cjj8bzp6wto5kyc3tup1igxaxlwggah8uy0774mepzyxyyyzs' );
define( 'SECURE_AUTH_SALT', 'eczxjzndexj7uo9mau87so6scjkz79gwczjw071hrgc0ezxhnqbjxcu8vcg83w2w' );
define( 'LOGGED_IN_SALT',   'umqrqnprbumtj7ohnw0qrf10yigcca44sj4i5uks0pwzgafcq08ffizicnoagnbm' );
define( 'NONCE_SALT',       '40d6soivwx5iviq9jjbo2r9gcj03avpycwggdzncm1ovdnoo56tljif7rahl8eaa' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpct_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
